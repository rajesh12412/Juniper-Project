import React, { useState, useEffect } from "react";
import Select from "react-select";
import data from './data.json';
import './style.css';

function AirportChooser() {
  const [country, setCountry] = useState(null);  
  const [state, setState] = useState(null);
  const [city, setCity] = useState(null);
  const [name, setName] = useState(null);
  const [code, setCode] = useState(null);
  let [stateArray, setStateArray] = useState(null);
  let [cityArray, setCityArray] = useState(null);
  const handleCountryChange = (obj) => {

    setCountry(obj);
    stateArray = data.filter(d => d.country == obj.country);
    setStateArray(stateArray);
    setState(obj);
    setCity(obj);
    setName(obj);
    setCode(obj);
  };

  const handleStateChange = (obj) => {
    setState(obj);
    cityArray = data.filter(d => d.state === obj.state);
    setCityArray(cityArray);
    setCity(obj);
    setName(obj);
    setCode(obj);
    
  };

  const handleCityChange = (obj) => {
    setCity(obj);
  };

   const handleNameChange = (obj) => {
    setName(obj);
  };
  
   const handleCodeChange = (obj) => {
    setCode(obj);
  };

  return (
    <div className="App">
      <header className="bg-black">
        <h1>Welcome to the Juniper Dashboard</h1>
      </header>
      <section className="g1">
        <h3>Juniper Network</h3>
          <div style={{ width: 400, marginBottom: 20 }}>
        <b>Country</b>
        <Select
          placeholder="Select Country"
          value={country}
          options={data}
          onChange={handleCountryChange}
          getOptionLabel={x => x.country}
        />
        <br />
        <b>State</b>
        <Select
          placeholder="Select State"
          value={state}
          options={stateArray}
          onChange={handleStateChange}
          getOptionLabel={x => x.state}
        />
        <br />
        <b>City</b>
        <Select
          placeholder="Select City"
          value={city}
          options={cityArray}
          onChange={handleCityChange}
          getOptionLabel={x => x.city}
        />
        <br />
        <b>Airport Name</b>
        <Select
          placeholder="Select Name"
          value={name}
          options={name}
          onChange={handleNameChange}
          getOptionLabel={x => x.name}
        />
        <br />
        <b>Airport Code</b>
        <Select
          placeholder="Select Code"
          value={code}
          options={code}
          onChange={handleCodeChange}
          getOptionLabel={x => x.code}
        />
      </div>
      </section>
    </div>
  );
}

export default AirportChooser;
