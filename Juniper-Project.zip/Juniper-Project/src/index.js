import React from "react";
import ReactDOM from "react-dom";
import './style.css';
import AirportChooser from "./AirportChooser";

ReactDOM.render(<AirportChooser />, document.getElementById("root"));
